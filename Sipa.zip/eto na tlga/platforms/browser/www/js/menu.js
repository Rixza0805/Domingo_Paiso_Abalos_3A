var menuState = {
	
	create: function () {
      /*var nameLabel = game.add.text(30, 80, 'JUEGO DE ANNILLO', {fill: '50px Broadway', fill: '#ffffff' }); */
     var bg2 = game.add.image(0,0, 'menubg') ;
     bg2.scale.x=1.3;
        bg2.scale.y=3;
             btn=game.add.button(120, 260, 'start', this.start, this);
             btn.scale.x=2;
             btn.scale.y=2;
             // btn=game.add.button(100, 360, 'setting', this.setting, this);
             //  btn.scale.x=2;
             // btn.scale.y=2;
              // game.add.button(300, 450, 'back', this.instruction, this);
        nameLabel = game.add.text(100, 100, "SIPA", style);
        nameLabel.scale.x=2;
             nameLabel.scale.y=4;
    	nameLabel.stroke = "white";
    	nameLabel.strokeThickness = 5;
    	nameLabel.fixedToCamera = true;
         

    },

	start: function(){

		game.state.start('play');
	},
 //    setting: function(){

 //        game.state.start('setting');
 //    },

	// creator: function(){

	// 	game.state.start('creator');
	// },
 //    instruction : function(){
 //        game.state.start('instruction');
 //    },
 //    about : function(){
 //        game.state.start('about');
  //  }
}