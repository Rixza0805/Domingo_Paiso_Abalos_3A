var loadState = {
	
	preload: function(){
		
	 game.load.image('background', 'img/f.png');
	 game.load.image("menu", 'img/options-bg.jpg');
	game.load.image("menubg", 'img/bg.png');
	game.load.image("start", 'img/start.png');




	game.load.image('ground', 'img/platform.png'); 
        game.load.image('player', 'img/tao.png'); 
        game.load.audio("sound", 'music/soundeffect2.mp3');
        game.load.image("pause",'img/pause.png');
        game.load.image("restart",'img/restart1.png');
        game.load.image("ball",'img/ball.png', 200, 200);

        game.load.audio("bgMusic","music/bg.wav");
                     // game.load.audio("scream","music/scary.wav");

        game.load.image("btnRight", "img/right.png",process.walkRight);
        game.load.image("btnLeft", "img/left.png",process.walkLeft);
        game.load.image("btnUp", "img/up.png",process.walkUp);
	},

	
	create: function (){
		game.state.start('menu');
	}

}