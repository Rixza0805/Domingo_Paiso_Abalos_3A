var w = 360, h = 500;

var game = new Phaser.Game(w, h, Phaser.CANVASS, '');
var platforms;
var cursors;
var ground;
var sound;
var stopText;
var restart;
var player, keyboard, pauseText;
var pause, scoreText ,gameOverText;
var score = 0;
var bestScoreText;
var gameOver;
var btn5;
var messageText;

var style = { font: "bold 32px Broadway", fill: "black" };

game.state.add('boot', bootState);
game.state.add('load', loadState);
game.state.add('menu', menuState);
game.state.add('play', playState);
game.state.start('boot');