var playState = {
	
	create: function(){
  game.physics.startSystem(Phaser.Physics.ARCADE);
        game.add.sprite(0, 0, 'background');

        sound = game.add.audio('sound',1, true);
        sound.loop =true;
        sound.play();


ek = game.add.group();
            ek.enableBody = true;
            bgAudio = game.add.audio("bgMusic");
            bgAudio.play();
            process.audio(123800);

          

            game.input.onDown.add(process.unpause, self);
        this.btn = game.add.button(300,10, 'pause',process.pause);
        this.btn.scale.x = 1;
        this.btn.scale.y = 1;
        //this.btn.inputEnabled = true;

         btn = game.add.button(250,10,"restart",process.restart);

        btn = game.add.button(100,400, 'btnRight', process.walkRight);
        btn.scale.x = 0.9;
        btn.scale.y = 0.9;
       

        btn = game.add.button(0,400, 'btnLeft',process.walkLeft );
        btn.scale.x = 0.9;
        btn.scale.y = 0.9;
        

        btn = game.add.button(50,340, 'btnUp', process.walkUp );
        btn.scale.x = 0.9;
        btn.scale.y = 0.9;
       



        scoreText= game.add.text(0,5,'Score:  ',
            {
                fontSize:'30px', fill:'black', stroke:'black'});
         bestText= game.add.text(0,30,'Best:  '+process.getData(),
            {
                fontSize:'30px', fill:'black' });
        gameOverText = game.add.text(20,20,"",
          {
            fontSize:'30px', fill:'black'});
         pauseText = game.add.text(0, 250, '', { fontSize: '300px', fill: 'white' });


       
        platforms = game.add.group();
        platforms.enableBody = true;
       
        ground = platforms.create(0,485, 'ground');
        ground.scale.setTo(2, 1);
        // game.physics.enable(ground, Phaser.Physics.ARCADE);
        // ground.body.collideWorldBounds = true;
          ground.enableBody = true;
       

        ground.body.immovable = true;
        cursors = game.input.keyboard.createCursorKeys();


        player = game.add.sprite(game.width/1.25,game.height-h,"player");
         game.physics.arcade.enable(player);
         player.enableBody = true;
        player.body.gravity.y =150;

        player.body.bounce.y = .5;
        player.body.collideWorldBounds = true;

     
        
        ball= game.add.audio('ball');
        ball=game.add.sprite(150,0,'ball');

        //shuttle.anchor.setTo(0.5, 0.5);

        game.physics.enable(ball, Phaser.Physics.ARCADE);   
        ball.body.collideWorldBounds = true;
        ball.body.bounce.y = 1;  
        ball.body.gravity.y =50; 
        //   ball.body.gravity.x =50; 


	},

	update: function() {
     game.physics.arcade.overlap(player,platforms);
        game.physics.arcade.collide(player,ball, process.scoreMe, null, this);
        game.physics.arcade.collide(platforms,ball, process.killball,null,this);

        game.physics.arcade.overlap(player, ball, process.scoreMe, null, this);
        game.physics.arcade.overlap( platforms,ball,process.killball,null,this);


            if (cursors.left.isDown) {
               
                player.body.velocity.x=-120;
                player.animations.play('btnLeft');
            }
            else if (cursors.right.isDown) {
          
                player.body.velocity.x=120;
                player.animations.play('btnRight');
            } 
            else {
                   player.body.velocity.x=0;

              player.frame = 1;
            }

            if (game.input.currentPointers == 0 && !game.input.activePointer.isMouse){ fire=false; right=false; left=false; duck=false; jump=false;} //this 
        }


};