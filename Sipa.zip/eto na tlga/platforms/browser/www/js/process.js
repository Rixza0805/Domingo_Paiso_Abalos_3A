var process = function() {
       "use strict";
        return {
 

 scoreMe:function(player,ball){
        score=score+1;
        if(process.getData()<=score){
            process.saveData(score);
            bestText.text="Best:"+score;
            console.log("x");
        }
        scoreText.text="Score:"+score;        
    },



    //  killball:function(ground, ball){
      
    //        ball.kill();

    //  setTimeout(function(){
        
    //     game._paused = true;
    // }, 100000000)
    // game._paused = true;
 
    //   gameOverText.text="GAMEOVER: \n   Best:"+process.getData() +"\n   Score:"+score;
    //   game.state.start("gameover");


    // },
 killball:function(platforms, ball){
            ball.kill();
            //game.state.start("Gameover"); if(process.getData()<=score){
            process.saveData(score);
            bestText.text="Best:"+score;
            console.log("x");
        
        scoreText.text="Score: "+score;        
    },


     killball:function(platforms, ball){
        /*lives= lives - 1;*/
           ball.kill();
           game._paused = true ;
           // game.state.start("Gameover");
          game.add.text(game.world.width-290,game.world.height-300,'GAMEOVER!!! \nBest:'+process.getData()+' \nScore:'+ score,
          {fontSize:'35px', fill:'red'});
         // restarts = game.add.text(w-200,h-100,'\n\n--tap--',{ fontSize:'35px', fill:'red'});
       
         // restart();
            
    },
    audio : function(time){
    setInterval(function(){
        bgAudio.play();
        },time)
 

},

    
     saveData:function(score){
        localStorage.setItem("gameData",score);
    },


     getData:function(){
        var data= localStorage.getItem("gameData");
        if(data==null|| data==""){
            data=0
        }
        return data;
    },
  

pause : function(){
    game.paused = true;
    pauseText.text ='GAME PAUSED,tap to start';
},

    unpause:  function (event){
      
   game.paused = false;
    pauseText.text = '';
},

    restart:function(){
        location.reload();
    },
 walkRight: function(){
    player.body.velocity.x = 150;
  player.animations.play("btnRight");
       
},

walkLeft: function(){
  player.body.velocity.x = -150;
  player.animations.play("btnLeft");
},

 walkUp : function(){
     player.body.velocity.y = -150;
},


}

}();


